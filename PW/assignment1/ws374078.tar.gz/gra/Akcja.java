package gra;

public interface Akcja {

    void wykonaj(Postać postać);

}
