package gra;

public interface Postać {

    int dajWysokość();

    int dajSzerokość();

}
