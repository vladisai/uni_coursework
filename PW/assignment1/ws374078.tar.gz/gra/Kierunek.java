package gra;

public enum Kierunek {

    GÓRA, DÓŁ, LEWO, PRAWO

}
