package gra;

@SuppressWarnings("serial")
public class DeadlockException extends Exception {

}
